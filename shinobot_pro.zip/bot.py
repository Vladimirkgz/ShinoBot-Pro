
from telebot import TeleBot
import config
from database.db import init_db
from handlers import admin, master

bot = TeleBot(config.BOT_TOKEN)

init_db()

admin.register(bot)
master.register(bot)

print("ShinoBot PRO started")
bot.infinity_polling()
