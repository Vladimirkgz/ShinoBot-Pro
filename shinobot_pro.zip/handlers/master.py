
from telebot import types
import config
from database.db import conn

current_master = {}

def get_free_post():
    c = conn()
    cur = c.cursor()

    for p in range(1, config.POSTS+1):
        cur.execute("SELECT COUNT(*) FROM orders WHERE post=? AND status='work'",(p,))
        if cur.fetchone()[0] == 0:
            c.close()
            return p

    c.close()
    return None

def register(bot):

    @bot.message_handler(commands=['start'])
    def start(m):

        c = conn()
        cur = c.cursor()
        cur.execute("SELECT name FROM masters")
        masters = cur.fetchall()

        kb = types.ReplyKeyboardMarkup(resize_keyboard=True)

        for master in masters:
            kb.add(master[0])

        bot.send_message(m.chat.id,"Выберите мастера",reply_markup=kb)

    @bot.message_handler(func=lambda m: m.text and m.text not in ["Новый клиент","Завершить"])
    def choose_master(m):

        current_master[m.chat.id] = m.text

        kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
        kb.add("Новый клиент","Завершить")

        bot.send_message(m.chat.id,f"Мастер: {m.text}",reply_markup=kb)

    @bot.message_handler(func=lambda m: m.text == "Новый клиент")
    def new_client(m):

        msg = bot.send_message(m.chat.id,"Имя клиента")
        bot.register_next_step_handler(msg,phone_step)

    def phone_step(m):
        name = m.text
        msg = bot.send_message(m.chat.id,"Телефон")
        bot.register_next_step_handler(msg,car_step,name)

    def car_step(m,name):
        phone = m.text
        msg = bot.send_message(m.chat.id,"Машина")
        bot.register_next_step_handler(msg,service_step,name,phone)

    def service_step(m,name,phone):
        car = m.text

        c = conn()
        cur = c.cursor()
        cur.execute("SELECT name,price FROM services")
        services = cur.fetchall()

        kb = types.ReplyKeyboardMarkup(resize_keyboard=True)

        for s in services:
            kb.add(f"{s[0]} | {s[1]}")

        msg = bot.send_message(m.chat.id,"Выберите услугу",reply_markup=kb)
        bot.register_next_step_handler(msg,save_order,name,phone,car)

    def save_order(m,name,phone,car):

        service,price = m.text.split("|")
        price = int(price)

        master = current_master.get(m.chat.id,"")

        post = get_free_post()

        status = "work"
        if post is None:
            status = "queue"
            post = 0

        c = conn()
        cur = c.cursor()

        cur.execute(
            "INSERT INTO orders(client,phone,car,service,price,master,post,status) VALUES (?,?,?,?,?,?,?,?)",
            (name,phone,car,service,price,master,post,status)
        )

        c.commit()
        c.close()

        if status == "work":
            bot.send_message(m.chat.id,f"Машина на посту {post}")
        else:
            bot.send_message(m.chat.id,"Все посты заняты. Добавлено в очередь")

    @bot.message_handler(func=lambda m: m.text == "Завершить")
    def finish(m):

        master = current_master.get(m.chat.id)

        c = conn()
        cur = c.cursor()

        cur.execute(
            "SELECT id,price FROM orders WHERE master=? AND status='work' ORDER BY id DESC LIMIT 1",
            (master,)
        )

        row = cur.fetchone()

        if not row:
            bot.send_message(m.chat.id,"Нет активных заказов")
            return

        order_id,price = row

        cur.execute("UPDATE orders SET status='done' WHERE id=?",(order_id,))

        # move queue
        cur.execute("SELECT id FROM orders WHERE status='queue' ORDER BY id LIMIT 1")
        next_order = cur.fetchone()

        if next_order:
            nid = next_order[0]
            post = 1
            cur.execute("UPDATE orders SET status='work', post=? WHERE id=?",(post,nid))

        c.commit()
        c.close()

        bot.send_message(m.chat.id,f"Работа завершена. Чек: {price} сом")
