
from telebot import types
import config
from database.db import conn

def is_admin(user_id):
    return user_id in config.ADMINS

def register(bot):

    @bot.message_handler(commands=['admin'])
    def admin_panel(m):
        if not is_admin(m.from_user.id):
            return

        kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
        kb.add("Добавить мастера","Добавить услугу")
        kb.add("Касса сегодня")

        bot.send_message(m.chat.id,"Админ панель",reply_markup=kb)

    @bot.message_handler(func=lambda m: m.text == "Добавить мастера")
    def add_master(m):
        msg = bot.send_message(m.chat.id,"Имя мастера")
        bot.register_next_step_handler(msg,save_master)

    def save_master(m):
        c = conn()
        cur = c.cursor()
        cur.execute("INSERT INTO masters(name) VALUES (?)",(m.text,))
        c.commit()
        c.close()

        bot.send_message(m.chat.id,"Мастер добавлен")

    @bot.message_handler(func=lambda m: m.text == "Добавить услугу")
    def add_service(m):
        msg = bot.send_message(m.chat.id,"Название услуги")
        bot.register_next_step_handler(msg,service_price)

    def service_price(m):
        name = m.text
        msg = bot.send_message(m.chat.id,"Цена (сом)")
        bot.register_next_step_handler(msg,save_service,name)

    def save_service(m,name):
        price = int(m.text)

        c = conn()
        cur = c.cursor()
        cur.execute("INSERT INTO services(name,price) VALUES (?,?)",(name,price))
        c.commit()
        c.close()

        bot.send_message(m.chat.id,"Услуга добавлена")

    @bot.message_handler(func=lambda m: m.text == "Касса сегодня")
    def cash(m):
        c = conn()
        cur = c.cursor()

        cur.execute("SELECT SUM(price) FROM orders WHERE status='done'")
        total = cur.fetchone()[0]

        if total is None:
            total = 0

        bot.send_message(m.chat.id,f"Касса сегодня: {total} сом")
