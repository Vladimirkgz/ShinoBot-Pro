
ShinoBot PRO

Telegram CRM для шиномонтажа

Функции:
- мастера
- услуги
- 3 поста
- очередь машин
- база клиентов
- касса

Запуск:

1. Создать бота через BotFather
2. Добавить BOT_TOKEN в Railway
3. Deploy
