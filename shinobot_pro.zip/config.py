
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")

# Replace with real Telegram IDs
ADMINS = [111111111, 222222222]

DB_PATH = "database/database.db"

POSTS = 3
